function navToggler(val){
    let bar = val.querySelector('#bar');
    let times = val.querySelector('#times');
    bar.classList.toggle('d-none');
    times.classList.toggle('d-none');

}


